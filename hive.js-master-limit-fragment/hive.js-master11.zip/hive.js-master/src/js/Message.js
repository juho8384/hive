/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


Message = function() {
    this.msgId;
    this.length;
    this.hash;
    this.rcvMesgData = null;
    
    this.onLoad = function(bytes) {

    }
}