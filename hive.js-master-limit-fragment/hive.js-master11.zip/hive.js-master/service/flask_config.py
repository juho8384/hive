DEBUG = True
STATIC_PATH = '../demo'
